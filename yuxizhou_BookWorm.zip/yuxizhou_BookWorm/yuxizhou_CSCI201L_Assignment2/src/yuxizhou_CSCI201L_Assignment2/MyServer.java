package yuxizhou_CSCI201L_Assignment2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray; 
import org.json.simple.JSONObject;
import org.json.simple.parser.*;


/**
 * Servlet implementation class MyServer
 */
@WebServlet("/MyServer")
public class MyServer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServer() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String type = request.getParameter("Type");
		
		String username = request.getParameter("username");
		
		String password = request.getParameter("password");
		
		String bookid = request.getParameter("ID");
		
		
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();
		
		
		System.out.println("In Server");
		if (type.equals("Login")) {
			
			int result = SQL.Login(username, password);
			
			if (result == 0) {
				
				out.println(0);
			}
			else if (result == 1) {
				
				out.println(1);
			}
			else {
				
				out.println(2);
				
				HttpSession session = request.getSession();
				session.setAttribute("username", username);
			}
			
			out.close();
			
			
		}
		else if (type.equals("Register")){
			
			
			boolean result = SQL.Register(username, password);
			
			if (result) {
				
				out.println("1");
			}
			else {
				
				out.println("0");
			}
			
			out.close();

		}
		else if (type.equals("Logout")) {
			
			HttpSession session = request.getSession();
			session.removeAttribute("username");
		}
		else if (type.equals("Favorite")) {
			
			SQL.addBookID(username, bookid);
			
		}
		else if (type.equals("Remove")) {
			
			SQL.removeBookID(username, bookid);
		}
		
		
	}

}
