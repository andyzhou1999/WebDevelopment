package yuxizhou_CSCI201L_Assignment2;

import java.sql.*;
import java.util.ArrayList;


public class SQL {
	
	public static int Login(String username, String password) {
		// -1: exception 0: user name does not exist 1: incorrect password 2: login succeed
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://google/WebUsers?cloudSqlInstance=cs201-sql-255419:us-central1:cs201lab8&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false&user=andy&password=123456");
			st = conn.createStatement();
			
			PreparedStatement ps = conn.prepareStatement("select Username, Password from allUsers where Username= ?");
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			if (!rs.next()) {
				
				return 0;
				}
			
			String user_password = rs.getString("Password");
			
			if (user_password.equals(password)) {
				
				
				return 2;
				}
			else {
				
				
				return 1;
				}
			
			
		}
		catch (SQLException e) {
			
			e.printStackTrace();
			return -1;
			
		}
		
		
	}
	
	public static boolean Register(String username, String password) {
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs= null;
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://google/WebUsers?cloudSqlInstance=cs201-sql-255419:us-central1:cs201lab8&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false&user=andy&password=123456");
			
			PreparedStatement ps = conn.prepareStatement("select Username from allUsers where Username= ?");
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			if (!rs.next()) {
				
				ps = conn.prepareStatement("insert into allUsers (Username, Password) values ( ? , ?)");
				ps.setString(1, username);
				ps.setString(2, password);
				ps.executeUpdate();
				
				
				
				return true;
			}
			else {
				
				return false;
			}
			
			
		}
		catch (SQLException e) {
			
			
			e.printStackTrace();
			return false;
		}
	}
	
	public static ArrayList<String> getFavorite(String username) {
		
		Connection conn = null;
		ResultSet rs= null;
		ArrayList<String> IDs = new ArrayList<String>();
		try {
			conn = DriverManager.getConnection("jdbc:mysql://google/WebUsers?cloudSqlInstance=cs201-sql-255419:us-central1:cs201lab8&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false&user=andy&password=123456");
			
			
			
			PreparedStatement ps = conn.prepareStatement("select userID from allUsers where Username= ?");
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			if (rs.next()) {
				
				int userid = rs.getInt("userID");
				ps = conn.prepareStatement("select BookID from Favorite where userID= ?");
				ps.setInt(1, userid);
				ResultSet RS = ps.executeQuery();
				
				while (RS.next()) {
					
					String BookID = RS.getString("BookID");
					IDs.add(BookID);
				}
			}
			
			
			return IDs;
		}
		catch(SQLException e) {
			
			e.printStackTrace();
			return IDs;
		}
		
	}
	
	public static void addBookID(String username, String bookid) {
		
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs= null;
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://google/WebUsers?cloudSqlInstance=cs201-sql-255419:us-central1:cs201lab8&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false&user=andy&password=123456");
			
			
			PreparedStatement ps = conn.prepareStatement("select userID from allUsers where Username= ?");
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			
			
			if (rs.next()) {
			
				int userid = rs.getInt("userID");
				
				ps = conn.prepareStatement("insert into Favorite (BookID, userID) values (? , ?)");
				ps.setString(1, bookid);
				ps.setInt(2, userid);
				
				ps.executeUpdate();
			}
		}
		catch(SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	public static void removeBookID(String username, String bookid) {
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs= null;
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://google/WebUsers?cloudSqlInstance=cs201-sql-255419:us-central1:cs201lab8&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false&user=andy&password=123456");
			
			
			PreparedStatement ps = conn.prepareStatement("select userID from allUsers where Username= ?");
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			if (rs.next()) {
				int userid = rs.getInt("userID");
			
				ps = conn.prepareStatement("delete from Favorite where BookID= ? and userID= ?");
				ps.setString(1, bookid);
				ps.setInt(2, userid);
				ps.executeUpdate();
			}
		}
		catch(SQLException e) {
			
			e.printStackTrace();
		}
		
	
		
		
	}
	
	

}
